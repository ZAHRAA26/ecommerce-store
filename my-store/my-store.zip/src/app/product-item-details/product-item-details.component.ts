import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Product } from '../models/Product';
import { HttpClient } from '@angular/common/http';
import { ProductService } from 'app/services/product.service';

@Component({
  selector: 'app-product-item-details',
  templateUrl: './product-item-details.component.html',
  styleUrls: ['./product-item-details.component.css']
})
export class ProductItemDetailsComponent {
product :Product;
constructor(private route: ActivatedRoute,private productService:ProductService){
  this.product={
    id:1,
    name:"",
    price:0.0,
    description:"",
    url:""

  }
}
ngOnInit() {
  this.route.queryParams.subscribe(params => {
    this.productService.getProducts().subscribe(data=>{
     console.log(data.filter(p=>p.id===params['id']))
     })
  });
  }
}
