import { Component,Input } from '@angular/core';
import { Product } from '../models/Product';
import {ProductService}from "../services/product.service"

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent {
@Input() product:Product
constructor(private productService:ProductService){
  this.product={
    id:1,
    name: "",
    price: 0.0,
    url: "",
    description: ""
  }

  }
  addToCart(product:Product){
    this.productService.addToCart(product)
    alert("Product added!");
  }
}

